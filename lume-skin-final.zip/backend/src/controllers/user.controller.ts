import User from "../models/User";

export const createUser = async (req:any, res:any) => {
  const user = await User.create(req.body);
  res.json(user);
};

export const getUsers = async (_:any, res:any) => {
  const users = await User.find();
  res.json(users);
};